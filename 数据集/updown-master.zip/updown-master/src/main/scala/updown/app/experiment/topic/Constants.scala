package updown.app.experiment.topic

object Constants {
  final val IGNORE_INSTANCE = "IGNORE_INSTANCE"

}
