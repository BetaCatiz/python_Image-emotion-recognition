package updown.preproc.model
abstract class TweetParse
case class FailedParse() extends TweetParse